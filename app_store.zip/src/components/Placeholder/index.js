import React, { Component } from 'react';
import './index.scss'

export default class Placeholder extends Component {
  
  render() {
    return (
      <div className="palceholder"></div>
    );
  }
}